const mysql = require('mysql');
const jwt = require('jsonwebtoken');

const connection = mysql.createConnection({
  host: process.env.RDS_LAMBDA_HOSTNAME,
  user: process.env.RDS_LAMBDA_USERNAME,
  password: process.env.RDS_LAMBDA_PASSWORD,
  port: process.env.RDS_LAMBDA_PORT,
  database: 'fcjresbar',
  connectionLimit: 1000,
  multipleStatements: true,
  connectTimeout: 60 * 60 * 1000,
  acquireTimeout: 60 * 60 * 1000,
  timeout: 60 * 60 * 1000,
  debug: true
});

const generateToken = (id) => {
  var JWT_SECRET = "0bac010eca699c25c8f62ba86e319c2305beb94641b859c32518cb854addb5f4";
  
  return jwt.sign({ id }, JWT_SECRET, {
    expiresIn: '30d'
  });
};

exports.handler = (event, context, callback) => {
  console.log('Inside Lambda with event:', event);

  context.callbackWaitsForEmptyEventLoop = false;

  if (event.method === 'POST') {
    const sql = 
      `INSERT INTO Users (name, email, password, image, isAdmin, createdAt, updatedAt) 
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `;
    
    const data = [
      event.name,
      event.email,
      event.password,
      event.image,
      event.isAdmin,
      event.createdAt,
      event.updatedAt
    ];

    connection.query(sql, data, (err, result) => {
      if (err) {
        console.error("Error executing query:", err);
        return callback(err);
      }

      const token = generateToken(result.insertId);

      callback(null, {
        status: 'success',
        message: 'User created successfully!',
        token: token,
        userId: result.insertId
      });
    });
    
  } else if (event.method === 'DELETE') {
    const sql = 'DELETE FROM Users WHERE id = ?';
    
    if (!event.userId) {
      return callback(null, {
        status: 'error',
        message: 'User ID is required for deletion'
      });
    }

    connection.query(sql, [event.userId], (err, result) => {
      if (err) {
        console.error("Error executing query:", err);
        return callback(err);
      }

      if (result.affectedRows === 0) {
        return callback(null, {
          status: 'error',
          message: 'User not found'
        });
      }

      callback(null, {
        status: 'success',
        message: 'User deleted successfully',
        userId: event.userId
      });
    });
  } else if (event.method === 'GET') {
    const sql = 'SELECT id, name, email, image, isAdmin, createdAt, updatedAt FROM Users';

    connection.query(sql, (err, results) => {
      if (err) {
        console.error("Error executing query:", err);
        return callback(err);
      }

      callback(null, {
        status: 'success',
        users: results
      });
    });
  } else {
    callback(null, {
      status: 'error',
      message: 'Invalid method'
    });
  }
};